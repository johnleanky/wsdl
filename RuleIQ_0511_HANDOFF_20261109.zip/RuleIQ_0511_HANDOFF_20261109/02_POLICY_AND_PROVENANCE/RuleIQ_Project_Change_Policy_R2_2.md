# RuleIQ Project Change Policy
## Universal Guardrails for Prompt, Contract, Knowledge and Runtime Changes

**Status:** Normative project policy  
**Revision:** R2.2 — 2026-10-19; supersedes the preserved R2.1 baseline  
**Change class:** Policy/process only; no ScenarioAuthor, Core, schema, Generator, Validator or Pega runtime contract is changed by this revision  
**Scope:** ScenarioAuthor, UnitTestGenerator, Validator, Knowledge Areas, JsonSchema/JsonExample contracts, orchestration, persistence/lifecycle rules, transfer bundles, and future agents added to the same architecture.

---

## 1. Purpose

This policy defines how any project change MUST be designed, implemented, reviewed, validated, compressed, versioned, and handed off.

The goals are:

- preserve semantic correctness and architectural ownership;
- prevent hidden regressions and competing instructions;
- keep prompts deterministic, compact, and efficient for GPT-5.6 Sol;
- prevent one patch from silently changing unrelated behavior;
- keep runtime claims evidence-based;
- make every change reversible and transferable to another session;
- prevent prompt growth through duplicated prose;
- keep examples non-authoritative and contracts mechanically testable.

This policy applies even when a requested change appears small.

**Policy revision rule:** update this policy using its own stages: preserve the exact previous file and hash, identify the process delta and protected semantics, run a policy-specific static/adversarial review, and retain a rollback copy. A process-policy update alone cannot claim that project agents or runtime code were modified.

---

## 2. Normative Terms

- **MUST / MUST NOT** — mandatory.
- **SHOULD / SHOULD NOT** — default unless a documented reason exists.
- **MAY** — optional.
- **PASS** — validated against the stage acceptance criteria.
- **NOT EXECUTED** — the stage was not run.
- **NOT AVAILABLE** — validation evidence cannot be obtained in the current environment.
- **BLOCKED** — the change MUST NOT advance to the next stage.
- **REVIEW ONLY** — draft artifact is not the deployed/normative replacement.
- **PROVISIONAL** — evidence is promising but does not satisfy all acceptance gates.
- **LIVE PASS** — a named real runtime test was executed and its result independently observed; an ACK or a successful generation call alone is insufficient.

A stage is not complete merely because text was edited. Execution and validation are separate states.

---

## 3. Source-of-Truth Hierarchy

When sources disagree, use this order unless a more specific project contract states otherwise:

1. current live artifact being changed;
2. current runtime/tool output and exact persisted data;
3. active schema/Knowledge contract that owns the semantic fact;
4. validated current patch state;
5. older project artifacts used only as comparison evidence;
6. summaries, transfer notes, or remembered context.

Never edit from memory when the current artifact is available.

Never convert historical wording into current truth merely because it existed in an older prompt.

**Freshness boundary:** a last-observed Conversation or exported artifact establishes a *historical baseline*, not proof of the current Pega editor/deployment. Before a normative edit, read back the current target, compare its hash with the frozen baseline and STOP for a three-way reconciliation if it differs. A missing fresh readback permits offline research but not claiming an in-place production edit.

### 3.1 Evidence vs inference

Every important conclusion MUST be one of:

- **INPUT FACT** — directly present in RuleJSON, Memory, schema, Knowledge, tool output, or live runtime evidence;
- **DERIVED LOGIC** — deterministically derived from current authoritative inputs;
- **TEST EXPECTATION** — expected behavior used for validation;
- **UNPROVEN ASSUMPTION** — not allowed to become contract semantics.

Record **where** each fact was observed (artifact/version/path, tool request/response, scenario, phase and/or runtime event). An outgoing write request is not proof of persistence when its response is empty or inconclusive; Generator `Passed` is not Pega Unit Test `Passed`. Distinguish source-code interpretation from confirmed runtime return behavior.

Do not present inferred behavior as runtime fact.

---

## 4. One Fact, One Owner

Every semantic fact MUST have exactly one authoritative owner.

Derived layers MAY reference or consume the fact but MUST NOT redefine it.

Examples of current ownership principles:

- original RUT adapter owns coverage obligations;
- ScenarioAuthor owns Scenario selection, grouping, and projection semantics;
- dependencies supply execution evidence/witnesses unless they are themselves the original RUT;
- target JsonSchema owns physical requiredness;
- compiler mapping owns semantic-to-physical serialization;
- Generator materializes the target contract;
- Validator independently verifies the persisted Candidate;
- examples illustrate contracts but do not define them;
- persisted lifecycle rows, not assistant prose, own execution state.

If two locations appear to own the same fact, the change is BLOCKED until ownership is resolved.

---

## 5. Change Classification Before Editing

Every change MUST be classified before implementation.

Possible classes:

- semantic behavior;
- coverage/cardinality/grouping;
- dependency resolution;
- orchestration/concurrency;
- persistence/lifecycle;
- schema/physical contract;
- semantic-to-physical mapping;
- validation;
- Knowledge interpretation;
- examples/documentation;
- token/structure cleanup;
- tooling/runtime capability.

For each change, record:

- authoritative owner;
- affected artifacts;
- protected artifacts;
- expected behavioral delta;
- expected non-delta;
- rollback boundary.

A patch SHOULD touch the smallest possible owner set.

**Separate bug fixes from objective changes.** Expanding coverage obligations, retaining additional Scenarios, changing physical grouping, or shifting the source of test inputs is a semantic/product decision even when implemented by a one-line prompt edit. Record the intended cardinality and representability consequences; do not smuggle a new objective into a local proof fix.

---

## 6. Mandatory Staged Change Workflow

No production-relevant patch may skip the staged workflow.

### Stage 0 — Freeze Baseline

Record before modification:

- exact source artifact;
- version/checkpoint;
- SHA-256;
- relevant section extract;
- token proxy baseline;
- known regression case(s);
- current expected behavior.

No semantic changes are allowed in Stage 0.

**Validation:** baseline is reproducible.

---

### Stage 1 — Ownership and Blast-Radius Map

Define:

- who owns the semantic rule;
- which layers consume it;
- which artifacts MUST remain unchanged;
- which downstream contracts may be affected.

**Validation:** no ambiguous ownership remains.

---

### Stage 2 — Pre-Patch Competing-Instruction Audit

Search the full relevant corpus, not only the intended edit location.

Search exact wording plus conceptual synonyms and historical variants.

Classify each hit as:

- `KEEP`
- `REPLACE`
- `CONFLICT`
- `REDUNDANT`
- `UNRELATED`

Search for:

- old sequencing rules;
- old cardinality/grouping rules;
- duplicated requiredness;
- fallback prose;
- permissive wording that bypasses fail-closed logic;
- older terminology;
- example text that looks normative;
- generic rules that can override a new specialized rule.

**Validation:** unresolved competing formulations = `0`.

---

### Stage 3 — Canonical Semantic Contract + Pre-Implementation Simulation

Define the new behavior once, in the smallest authoritative form possible.

Prefer:

- one invariant;
- one mapping;
- one state transition rule;
- one adapter exception where needed.

Avoid implementation prose until semantics are stable.

Before Stage 4, semantic/behavioral patches MUST pass a **source-grounded preflight simulation → critique → correction → complete replay** (see §34). Record the independent oracle, known counterexamples, rejected revisions, runtime assumptions and explicitly protected semantics. Documentation-only patches may use documented structure/diff tests instead.

**Validation:** the canonical contract and applicable source-based cases PASS; unresolved runtime-only questions remain explicitly open.

---

### Stage 4 — Localized Implementation

Modify only the authoritative location(s).

Prefer replacement over additive patching.

Do not add a new rule beside an old conflicting rule.

Do not duplicate the same semantic rule in several sections “for clarity”.

If a downstream section needs the rule, reference the owner instead of restating the algorithm.

**Validation:** diff is localized, exact canonical OLD → NEW is reviewable, the observed deployed baseline still matches, and expected protected artifacts remain unchanged. No blanket approval to "start" grants approval of unseen semantic changes; follow §35.

---

### Stage 5 — Post-Patch Residual Audit

Repeat the Stage 2 search against the modified artifact.

Search both:

- wording that should have disappeared;
- wording newly introduced by the patch.

**Validation:** unresolved contradictions = `0`.

---

### Stage 6 — Static Contract Tests

Run positive, negative, boundary, and adversarial tests.

At minimum test:

- canonical success case;
- exact known regression;
- missing required evidence;
- contradictory evidence;
- unknown/ambiguous state;
- duplicate identity;
- unsupported mode/type;
- fail-closed behavior.

**Validation:** expected state transitions and outputs are deterministic within the stated model assumptions, with all applicable Stage 3 simulations replayed against the implemented artifact. Track historical examples as regression fixtures rather than relying only on newly invented cases.

---

### Stage 7 — Cross-Family Regression

Verify adjacent behavior was not damaged.

Examples:

- direct RUT vs nested dependency;
- Model vs When vs Decision Table;
- Property vs Page/List/ResultCount;
- single vs multiple groups;
- success vs negative lifecycle;
- blocking vs asynchronous orchestration where applicable.

**Validation:** protected behavior is unchanged.

---

### Stage 8 — Token and Attention Compression

Correctness comes first; compression comes after.

Then remove:

- duplicate prose;
- repeated examples;
- narrative explanation;
- redundant restatements;
- obsolete compatibility wording;
- multiple descriptions of the same invariant.

Prefer compact state models and single-owner references.

If an exact GPT-5.6 Sol tokenizer is unavailable, the project MAY use:

`proxy_tokens = ceil(chars / 4)`

This MUST be labeled as an approximation.

Every patch MUST define its own budget before implementation.

Recommended default for a small prompt patch:

- preferred net growth: `<= +50 proxy tokens`;
- default review threshold: `<= +100 proxy tokens`.

These are **defaults, not license to delete required behavior**. Assign a patch-specific preferred and maximum budget from its semantic obligations, surface and risk. An overage requires documented justification and explicit review/approval; do not label +100 an unwaivable technical limit. Large necessary changes may be split by owner/wave instead of compressed into ambiguity.

**Validation:** rerun semantic, regression and adversarial simulations after compression; required obligations survive. Record justified approved overages (§22).

---

### Stage 9 — Whole-Project Contradiction Validation

Review the complete modified prompt/contract, not only the diff.

Verify:

- authority hierarchy;
- ownership;
- lifecycle;
- coverage;
- grouping;
- dependency semantics;
- persistence;
- orchestration;
- validation boundaries;
- failure semantics;
- final response semantics.

**Validation:** unresolved contradictions = `0`.

---

### Stage 10 — Live Acceptance

Required whenever the changed behavior depends on runtime/tool semantics.

Static reasoning MUST NOT be presented as live evidence.

Examples requiring live proof:

- real parallel execution;
- detached asynchronous execution;
- polling behavior;
- tool transport behavior;
- exact persisted runtime payload;
- lifecycle timing;
- actual Pega rule behavior.

Use comparable live A/B runs where feasible; verify actual effective input state and Pega execution, not merely valid JSON or Generator `Passed`. Record both arms' versions, negative results and runtime variability; apply §36.

If the runtime is unavailable:

- mark stage `NOT EXECUTED`;
- mark validation `NOT AVAILABLE`;
- stop before production acceptance.

Never invent or simulate a live PASS.

---

### Stage 11 — Version, Rollback, Transfer

After all required validations:

- assign a version;
- store exact baseline;
- store final artifact;
- store exact diff;
- store validation report;
- store token report;
- store live evidence when applicable;
- store rollback instructions;
- store SHA-256 hashes;
- create a transfer bundle.

A patch without a reversible checkpoint is not production-complete.

Preserve both the previous normative artifact and the final verified artifact. Record the *actual* Library destination/identity after upload; a duplicate-safe filename or a sandbox copy is not proof that an existing normative file was updated.

---

## 7. Execute → Validate → Advance Rule

For every stage:

1. mark **execution status**;
2. complete the work;
3. mark **execution COMPLETED**;
4. run validation;
5. mark **validation PASS / FAIL / NOT AVAILABLE**;
6. proceed only after PASS.

Each checkpoint requiring approval MUST preserve the artifact/patch and the evidence being approved; approval of a design is not evidence of passing later tests.

If validation fails:

- do not advance;
- repair the same stage;
- rerun its validation;
- only then continue.

If validation is unavailable and is required for production acceptance, stop.

---

## 8. Prompt Writing Rules for GPT-5.6 Sol

Prompts SHOULD be:

- imperative and outcome-first;
- semantically precise;
- compact and evidence-verifiable;
- explicit about ownership and failure;
- free of motivational or explanatory filler.

For LLM-facing agent prompts, prefer **positive, outcome-first guidance**: state the expected evidenced output, its authoritative inputs, when it is valid, and the minimal failure state. Preserve model freedom to reason through the task; do not force long negative lists, internal algorithms, arbitrary fixed search orders or tool-use recipes unless a genuine contract demands them.

For deterministic machine contracts, precise guards may be appropriate. For example, prefer:

`If X, do Y; otherwise fail closed.`

over:

`You should generally try to do Y when X seems applicable.`

Prefer closed enumerations over open-ended prose.

Prefer exact canonical terms over synonyms when the term is part of a contract.

Do not use several names for the same state unless a mapping is explicitly defined.

---

## 9. Replace, Do Not Layer

A common source of regression is adding a new rule while leaving the old rule intact.

Default policy:

- replace conflicting wording;
- delete superseded wording;
- do not “clarify” by stacking another paragraph on top;
- do not preserve obsolete text for compatibility unless runtime evidence proves it is required.

A patch is incomplete if both old and new semantics remain reachable by the model.

---

## 10. Fail-Closed Policy

Unknown, ambiguous, malformed, unsupported, or contradictory evidence MUST NOT be repaired by guessing.

Fail closed when:

- identity cannot be proven;
- class/page/context cannot be resolved uniquely;
- runtime capability is required but unavailable;
- schema-required data is absent;
- dependency evidence is incomplete;
- tool execution is uncertain and retry may duplicate side effects;
- two authoritative sources conflict.

Do not “make the test work” by changing expected results to fit incomplete evidence.

---

## 11. No Invented Runtime Capabilities

A prompt MUST NOT invent:

- asynchronous dispatch;
- background polling;
- timers;
- sleeps;
- retries;
- parallelism;
- runtime states such as `Running`;
- tool parameters;
- lifecycle values.

If the tool/runtime does not prove the capability, keep it outside production semantics.

Concurrency is proven by overlapping execution evidence, not by tool-call ordering alone.

---

## 12. Dependency Containment

Dependencies are evaluated only to support original-RUT execution unless the dependency is itself the original RUT.

General invariant:

> Dependencies may provide evidence, values, side effects, or witnesses required by an original-RUT obligation, but must not silently become independent coverage owners.

This prevents:

- Decision Table row explosion;
- nested When branch explosion;
- Data Page value-combination explosion;
- RUF return-value explosion;
- dependency-driven Scenario cardinality.

Adapter-specific direct-RUT rules remain authoritative when that dependency type is the actual RUT.

---

## 13. Scenario Cardinality Guardrail

Scenario count MUST be driven by original-RUT obligations and proven original-RUT interactions.

Do not retain a Scenario merely because it represents another combination of already-covered independent effects.

A joint Scenario is justified only when the combination changes one of:

- original-RUT reachability;
- later original-RUT execution;
- overwrite/order semantics;
- termination/short-circuit behavior;
- collection/index/cardinality behavior;
- explicit adapter-required interaction.

Dependency-result diversity alone is never a retention reason.

---

## 14. Examples Are Non-Authoritative

JsonExample, sample payloads, comments, and explanatory examples:

- MUST conform to the contract;
- MUST NOT define requiredness;
- MUST NOT override schema or compiler mapping;
- MUST NOT be used to infer missing semantics.

If an example conflicts with its owner contract, fix or remove the example.

Do not copy example-specific fields into production logic without owner evidence.

---

## 15. Schema and Physical Contract Discipline

Physical requiredness belongs in schema/contract ownership.

Semantic-to-physical mapping belongs in the designated compiler/mapping owner.

Do not spread the same required-field rule across:

- Schema;
- Generator prompt;
- Validator prompt;
- examples;
- Knowledge prose.

Consumer prompts MAY reference the authoritative contract but SHOULD NOT duplicate its algorithm.

---

## 16. Validation Independence

Generator and Validator responsibilities MUST remain independent.

The system MUST avoid circular validation where:

- Generator defines what is valid;
- Validator merely repeats Generator prose.

Validator should validate persisted evidence/contract independently.

ScenarioAuthor MUST NOT repair Candidate output.

Generator MUST NOT silently reinterpret frozen ScenarioAuthor semantics.

---

## 17. Persistence and Immutability

Once an artifact is declared frozen/immutable:

- later phases may consume it;
- later phases may not rewrite its semantic content;
- lifecycle fields may change only through the designated owner;
- identity/group/case ownership must remain stable.

Never use “latest matching record” when an exact GUID is available.

Never substitute one projection/candidate for another.

---

## 18. Exactly-Once and Retry Safety

For side-effecting calls:

- every intended identity must be correlated exactly;
- uncertain execution MUST NOT be retried if retry can duplicate state;
- duplicate GUID/case/group execution is a failure;
- transport ACK is not semantic success unless the contract says so.

Exactly-once safety takes precedence over convenience.

---

## 19. Residual-Conflict Audit Strategy

A good residual audit searches concepts, not only exact phrases.

For every semantic change, search:

- old term;
- new term;
- synonyms;
- inverse phrasing;
- old section headings;
- known legacy terminology;
- generic fallback wording;
- prose around completion gates;
- examples;
- transfer/checkpoint text if reused as active input.

Examples:

A change from sequential to parallel orchestration must search for:

- sequential;
- canonical order;
- immediately after;
- next group;
- wait;
- one-by-one;
- exactly one immediate read.

A cardinality change must search for:

- distinct;
- retain;
- representative;
- material profile;
- all combinations;
- Cartesian;
- split;
- group;
- result class.

---

## 20. Test Matrix Requirements

Every non-trivial patch SHOULD include source-backed expectations and an independent reason for each result. Distinguish logical reachability, physical representability, actual execution, persisted evidence and retained coverage.

### Positive
Expected canonical success.

### Negative
Missing/invalid evidence.

### Adversarial
Conflicting, duplicate, stale, or ambiguous data.

### Boundary
Minimum/maximum counts, empty/nonempty, direct/nested modes.

### Exact Regression
The concrete run that motivated the patch.

### Cross-Family
Adjacent RUT or assertion families.

### Fail-Closed
Prove the system rejects unsupported ambiguity instead of inventing a result.

### No-Change Regression
Prove protected artifacts and semantics remain unchanged.

---

## 21. Static vs Live Evidence

Every report MUST clearly label each validation as one of:

- source/diff static analysis;
- abstract Boolean or state-machine simulation;
- source-backed execution-replay simulation;
- schema/physical-shape validation;
- LLM conversation/tool-trace live observation;
- Pega rule/unit-test execution live;
- other tool/runtime live execution.

For every result, state the oracle, inputs, assumptions, artifact hashes, test count and **what it does not prove**. Schema-valid input cells do not prove Pega materialization, and a correct Boolean oracle does not prove the LLM will construct that witness. The words `PASS` and `COMPLETE` must always specify their layer.

Never call static analysis a runtime test.

Never claim a tool worked asynchronously unless live evidence proves it.

Never claim a Pega rule persisted correctly without persisted runtime evidence.

---

## 22. Token Budget Policy

Before editing, define:

- baseline prompt size;
- target section size;
- preferred net delta;
- patch-specific maximum net delta (with reason and approval).

During implementation, semantic clarity may temporarily exceed the budget.

Before finalization, compress.

After compression, rerun all tests that validated the verbose candidate.

Token optimization MUST NOT:

- merge distinct semantic states;
- delete failure handling;
- replace deterministic rules with vague prose;
- move ownership into examples;
- rely on model intuition.

---

## 23. Change Locality and Blast-Radius Control

A patch SHOULD modify only the smallest authoritative surface.

If a ScenarioAuthor rule can be fixed in its owning Knowledge/ScenarioAuthor contract, do not edit Core, Generator or Validator unless evidence shows they are also inconsistent.

If a schema requiredness rule is wrong, fix the schema owner first rather than duplicating a workaround in consumers.

Cross-artifact edits require an ownership justification.

---

## 24. Protected Invariants

Each patch MUST declare protected invariants before implementation.

Typical protected invariants include:

- exact identity correlation;
- immutable source records;
- original-RUT ownership;
- fail-closed semantics;
- no invented Candidate data;
- no dependency-owned Scenario count;
- no cross-projection mutable state;
- one authoritative lifecycle row;
- one Generator per frozen Projection;
- Validator independence;
- examples non-authoritative.

A patch that changes a protected invariant becomes a separate architectural change and requires its own plan.

---

## 25. Stop Conditions

Stop the change and do not advance when:

- ownership is ambiguous;
- a required current artifact cannot be retrieved for the operation requested (historical offline research may continue in `REVIEW ONLY`);
- residual conflict count is nonzero;
- a protected invariant regresses;
- the explicitly approved patch-specific token maximum is exceeded without renewed approval;
- a required live capability cannot be tested;
- runtime behavior differs from the prompt model;
- rollback cannot be performed safely.

Do not hide a blocked stage by declaring the whole patch complete.

---

## 26. Versioning Policy

Recommended format:

`vYYYY.MM.DD.N[-exp]_<CHANGE_NAME>`

Examples:

- `v2026.10.07.1-exp_PARALLEL_GENERATOR`
- `v2026.10.07.2-exp_RUT_OWNED_CARDINALITY`

Use `-exp` until required live acceptance passes.

A production version MUST NOT be promoted solely from static validation when the patch depends on runtime semantics.

---

## 27. Transfer Bundle Requirements

Every transferable checkpoint SHOULD contain:

- `CURRENT_STATUS.md`
- `VERSION.txt`
- current authoritative prompts
- changed Knowledge/schema/example files
- exact baseline
- exact diff
- test matrix/results
- residual audit
- token report
- live evidence, if available
- hashes
- rollback instructions
- unresolved work / next stage

The transfer status MUST say exactly where work stopped.

---

## 28. Standard Stage Status Format

Use:

```text
Stage N — execution: COMPLETED
Stage N — validation: PASS
```

or:

```text
Stage N — execution: NOT EXECUTED
Stage N — validation: NOT AVAILABLE
```

If failed:

```text
Stage N — validation: FAIL
Reason: <exact conflict>
Action: remain on Stage N
```

Never move to Stage N+1 before Stage N validation passes.

---

## 29. Standard Change Plan Template

```text
Change name:
Baseline version:
Authoritative owner:
Affected artifacts:
Protected artifacts:
Expected behavior change:
Expected non-change:
Token budget:
Live validation required: YES/NO
Current-editor readback available: YES/NO; historical fallback:
Source-backed oracle and simulation matrix:
Physical/schema representability checks:
Explicit semantic/objective expansion: YES/NO; owner approval:
Approval checkpoints / rollback boundary:

Stage 0  Baseline freeze
Stage 1  Ownership map
Stage 2  Pre-patch residual audit
Stage 3  Canonical semantics + offline simulation/critique/revision
Stage 4  Localized implementation
Stage 5  Post-patch residual audit
Stage 6  Static tests
Stage 7  Cross-family regression
Stage 8  Compression
Stage 9  Whole-project contradiction validation
Stage 10 Live acceptance
Stage 11 Version/rollback/transfer
```

Additional sub-stages MAY be inserted when the patch requires domain-specific validation; they do not bypass Stage 0–11 gates. In particular, the Stage 3 simulation/critique/revision loop and the explicit reviews in §35 are mandatory where applicable.

---

## 30. Standard Validation Report Template

```text
Artifact:
Baseline hash:
Candidate hash:

Execution status:
Validation status:

Changed owners:
Protected owners unchanged:

Static tests:
Exact regression:
Cross-family regression:
Residual conflicts:
Token delta and approved budget:
Oracle, source assumptions and preflight simulation cases:
Rejected candidates, critique and replay after corrections:
Live-vs-static boundary / what was NOT proven:
Approved gates and pending gates:

Live tests:
Runtime evidence:

Unresolved issues:
Next required stage:
```

---

## 31. Forbidden Anti-Patterns

The following are prohibited unless explicitly approved as architectural changes:

- adding a new rule without removing its conflicting predecessor;
- letting examples define semantics;
- relying on “latest” record instead of exact identity;
- silently changing ownership;
- broadening scope while fixing a local bug;
- creating fallback behavior from model intuition;
- calling static tests “live”;
- inferring Pega behavior from schema validity or from Generator `Passed`;
- treating the presence of a field, a declared class or an omitted input `value` as proof of an effective runtime page/list state;
- counting coverage labels without proving reachable original-RUT execution and final physical representation;
- silently changing coverage goals/cardinality while nominally fixing an unrelated witness;
- claiming asynchronous behavior without runtime evidence;
- retrying uncertain side-effecting calls;
- keeping redundant scenarios only because dependency outputs differ;
- duplicating compiler logic in multiple prompts;
- growing prompts indefinitely instead of replacing/compressing;
- marking a stage complete when validation was not run;
- assigning a production version before required live acceptance.

---

## 32. Definition of Done

A change is complete only when all applicable conditions are true:

- baseline is frozen;
- owner is explicit;
- expected behavior change is explicit;
- protected behavior is explicit;
- pre-patch residual audit is complete;
- canonical rule is deterministic;
- implementation is localized;
- post-patch residual conflicts = 0;
- static tests pass;
- exact regression passes;
- the source-grounded pre-implementation simulation/critique/correction loop was completed or explicitly justified as inapplicable;
- semantic-preservation and physical-representability assumptions were tested where relevant;
- cross-family regressions pass;
- token budget passes;
- whole-project contradiction audit passes;
- required live acceptance passes;
- all required owner, diff, post-edit, post-compression and release approvals are recorded;
- rollback is possible;
- hashes are recorded;
- final artifacts are saved;
- transfer bundle is complete.

If any required item is missing, the patch remains experimental/incomplete.

---

## 33. Core Project Principle

The architecture should become **more explicit and smaller** after each repair, not merely larger.

When fixing a defect:

1. identify the missing or incorrect invariant;
2. place it at the correct owner;
3. remove competing wording;
4. verify behavior mechanically;
5. compress duplicated logic;
6. prove protected behavior did not change;
7. only then promote the version.

The preferred repair is the smallest deterministic rule that restores the correct ownership boundary and eliminates the class of bug rather than only the observed instance.

---

## 34. Reproducible Simulation and Critical-Correction Protocol (R2.2)

**Purpose:** find weaknesses before changing the normative source; simulation is a *design instrument*, never a substitute for the real agent or Pega runtime.

For every semantic/behavioral candidate, record in a single reproducible evidence set:

1. **Authority and scope:** frozen source hash, original-RUT / contract and exact owner; current-vs-candidate diff; protected non-deltas.
2. **Independent oracle:** explicit input state, authoritative source/semantics, expected *reachable* execution/transition, expected persisted output and expected coverage. An assumption such as missing-list-is-empty is not an oracle without source and runtime evidence.
3. **Layered case matrix:** canonical positive, known regression, negative, boundary, UNKNOWN/error, conflicting input, source-order/short-circuit, nested dependency, phase drift, reduction and adversarial compliance. Apply only relevant dimensions; explain omissions.
4. **Materialization check:** where an output has a physical target, separately establish validity of the schema, the effective page/list/parameter state, per-row vs shared setup, column-signature effects and compatibility with grouping. Do not treat valid JSON as a proven runtime state.
5. **Outcome and critique:** record model result **versus oracle**, failure classification by owner, whether a correct witness was merely omitted or could not be represented, and at least one plausible way the proposed wording could be followed superficially while remaining wrong.
6. **Revision loop:** reject/repair the minimum owning rule; update the canonical OLD → NEW; rerun the complete impacted matrix **after every semantic revision**, including a compressed final candidate; keep iteration evidence and the final stop reason.

A patch MAY be rejected even when all programmed simulation assertions pass if the assertions merely restate the prompt, omit a known counterexample, or rely on unconfirmed runtime assumptions. Never report `N/N PASS` without the layer and oracle. An external new validator is **not** required by this section; use the existing project contracts and suitable offline models/fixtures.

---

## 35. Explicit Approval and Change-Wave Boundaries (R2.2)

Use intermediate review/approval checkpoints, separate from execution Stage numbers. For an independently reviewable, production-relevant change wave, record:

- **G0 — Baseline and ownership:** exact live source if accessible, source/historical status, protected surfaces and rollback.
- **G1 — Semantic design:** positive outcome, owner, objective/cardinality delta, affected and unchanged invariants, oracle and adversarial risks.
- **G2 — Canonical OLD → NEW:** complete proposed diff, prompt size/budget, Stage 3 simulation/critique results, explicit acceptance of any new coverage or schema behavior.
- **G3 — Implementation readback:** authorize and verify the exact applied bytes against the approved diff; after any baseline mismatch, return to G0–G2.
- **G4 — Residual/regression/compression review:** Stage 5–9 evidence, retested compressed text, remaining uncertainty and approved overages.
- **G5 — Live/release decision:** named Stage 10 tests and observed artifacts, unresolved defects, rollback decision and transfer snapshot.

Approval is **specific to the reviewed artifact, version and semantic delta**. Authorization to investigate or to start the workflow is not blanket authorization to apply an unseen patch, alter a coverage objective, or certify a run. If the user explicitly authorizes an identified implementation wave, execute within its stated scope and preserve all later validation gates. Separate waves by semantic owner; a follow-up failure in acquisition, coverage or witness proof does not authorize modifying whichever prompt was edited most recently.

A policy/process-only update can be reviewed and saved as a new normative policy revision without executing unrelated live Pega tests; explicitly record that no application behavior was proven or changed.

---

## 36. Live Feedback, Regression Metrics and Promotion (R2.2)

Before an A/B or acceptance run, establish the comparison contract: baseline/candidate hashes, original RUT and dependencies, input/setup, tool permissions, runtime context, projection/generator versions, and expected observable evidence. When a controlled baseline is impractical, report limitations rather than implying comparability.

For each real attempt, evaluate **independently**:

- *Discovery:* required sources acquired or a source-backed terminal acquisition blocker; no unsupported missing-identity shortcut.
- *Reasoning:* exact reached original-order execution, predecessor guards, call semantics, error/UNKNOWN handling and honest coverage identities.
- *State:* PLAN/PROVED/FROZEN and final effective seed consistent; absent/empty/page/list state grounded.
- *Representation:* physical rows and typed setup materialize the intended test state; no duplicate/conflicting authority for per-row values.
- *Persistence and execution:* actual write result, generated Rule identity and **observed real Pega test result** where required; do not infer persistence or execution from outgoing calls or generator ACKs.
- *Protection:* retained required coverage, scenario/group cardinality, adjacent adapters, fail-closed and immutable boundaries.

Classify each failure **at the earliest responsible owner**. If live results contradict the oracle: capture raw trace, determine whether the source/model assumption was wrong or the LLM/serializer did not follow a valid rule, change only the proven owner, rerun Stage 3 and Stage 5–9 as applicable, and repeat live A/B. Stop or roll back on false executable proof, loss of required coverage, broken protected invariant, materialization failure or ambiguous persistence. Do not convert a repeated local success into universal reliability; state sample size, observed variability and open tests.

---

## 37. Revision Record

- **R2.1 — frozen predecessor:** original 33-section policy, archived byte-for-byte; established ownership, staged workflow, fail-closed operation, token control and live acceptance.
- **R2.2 — 2026-10-19:** adds source-backed pre-implementation simulation and iterative critique/replay, explicit review checkpoints, layered evidence/representability acceptance, live feedback triage, runtime-vs-static boundary and outcome-first prompt guidance; clarifies dynamic token budgets, historical/live baseline freshness and policy-level change scope. **No RuleIQ agent prompt, runtime rule or coverage contract is modified by this policy edit.**
