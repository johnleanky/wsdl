RuleIQ 0511 — исходные Knowledge Areas для отката

Целевая точка: набор Knowledge Areas на начало проекта 5 ноября 2026 года, совместно с ранее подготовленным исходным Core + узкой RUF-правкой.
BASELINE_0511 в именах — обозначение этого среза, а не номер Pega Ruleset.

Содержимое шести TXT следует использовать для соответствующих Knowledge Areas:
Rule-Obj-Model_KnowledgeArea
Rule-Obj-Property_KnowledgeArea
Rule-Declare-DecisionTable_KnowledgeArea
Rule-Utility-Function_KnowledgeArea
Rule-Obj-When_KnowledgeArea
Rule-Declare-Pages_KnowledgeArea

Источники:
Model, Property, DecisionTable, RUF — точные файлы первоначального Project-update-0511(2).zip. Содержимое и байты сохранены без изменений.
When и Data Page — точные декодированные Description из исходного 0411-2141(2).zip, включая PXCONV-303482. When совпал во всех шести исходных Conversation, Data Page — в четырёх. When также побайтово совпал с 01_AUTHORITY/When_KnowledgeArea_LAST_OBSERVED_LIVE_20261019.txt первоначального handoff.

Поздние экспортные копии When/Data Page из 312035/315232 отличаются только заменами символов >, < и & на буквальные обратный слеш + подчёркивание. Для отката выданы чистые исходные тексты, а не эти поздние копии. Новая семантика и новые исправления не внесены. Ранее подготовленный protected_reference был материалом для сверки; для переноса When/Data Page в Pega используйте именно чистые файлы этого пакета.

Сохранённая RUF-правка находится в Core §5.5–5.6. RUF KnowledgeArea остаётся исходной. Core и Generator в этот архив не включены.

Какие Knowledge Areas действительно требуют отката, зависит от текущего содержимого Pega. Оно здесь не прочитано; установка или изменение Pega не выполнялись. Номера исторических Pega Ruleset versions в этих источниках отсутствуют, поэтому пакет идентифицирует версии по точному содержимому и SHA-256 в SOURCE_AND_HASHES.json.

Это восстановленные копии исходных файлов и фактического KnowledgeTool output. Новый live-прогон и доказательство безотказности не заявляются.
