"""Portable integrity check. Python standard library; no network, LLM or Pega."""
from pathlib import Path
import hashlib, json, zipfile, sys

P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((P/'MANIFEST_SHA256.json').read_bytes())
errors=[]
for name, meta in manifest['files'].items():
    f=P/name
    if not f.is_file():
        errors.append('Missing: '+name);continue
    b=f.read_bytes()
    if len(b)!=meta['bytes'] or sha(b)!=meta['sha256']:
        errors.append('Mismatch: '+name)
state=json.loads((P/'CURRENT_STATE.json').read_bytes())
for item in state['current_artifacts']:
    if sha((P/item['path']).read_bytes())!=item['sha256']:
        errors.append('Current mismatch: '+item['path'])
baseline=(P/'03_BASELINE/Agent_Scenario_Author_ORIGINAL_0511.txt').read_bytes()
spec=json.loads((P/'02_POLICY_AND_PROVENANCE/PATCH_SPEC.json').read_bytes())
text=baseline.decode()
for i in (1,2):
    old,new=spec['old'+str(i)],spec['new'+str(i)]
    if text.count(old)!=1:errors.append('Baseline patch occurrence mismatch: '+str(i))
    text=text.replace(old,new)
current_core=next(x for x in state['current_artifacts'] if x['role']=='ScenarioAuthor Core')
if text.encode()!=(P/current_core['path']).read_bytes():
    errors.append('Core differs from original plus two RUF replacements')
sources=json.loads((P/'02_POLICY_AND_PROVENANCE/SOURCE_INDEX.json').read_bytes())
for row in sources:
    if sha((P/row['package_path']).read_bytes())!=row['sha256']:
        errors.append('Source mapping mismatch: '+row['name'])
for archive in P.rglob('*.zip'):
    try:
        with zipfile.ZipFile(archive) as z:
            bad=z.testzip()
            if bad:errors.append('Archive CRC mismatch: '+str(archive.relative_to(P))+'/'+bad)
    except zipfile.BadZipFile:
        errors.append('Bad ZIP: '+str(archive.relative_to(P)))
result={'status':'FAIL' if errors else 'PASS','layer':'artifact integrity only',
        'manifest_files':len(manifest['files']),'current_artifacts':len(state['current_artifacts']),
        'source_items':len(sources),'indexed_conversations':state['raw_conversations_indexed'],
        'Pega_execution':'NOT EXECUTED','errors':errors}
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
